<template>
  <div>
    <h2>UsersPage Page</h2>
    <p>Welcome to the UsersPage!</p>
  </div>
</template>

<script>
export default {
  name: "UsersPage",
};
</script>
