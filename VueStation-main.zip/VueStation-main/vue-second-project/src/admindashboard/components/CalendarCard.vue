<template>
  <div class="calendar-card">
    <h3>CALENDAR</h3>
    <img src="https://i.ibb.co/r4Fjv6m/cal.png" class="calendar-img" />
  </div>
</template>

<style scoped>
.calendar-card {
  background: #fff;
  padding: 20px;
  border-radius: 10px;
}

.calendar-img {
  width: 100%;
}
</style>
